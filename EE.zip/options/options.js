"use strict";

var emailExtractorOptions = {
  saveEmailExtractorOptions: function(e) {
    e.preventDefault();
    if (document.querySelector("#extractionChoiceAll").checked) {
        browser.storage.local.set({
            extractFromAlltabs: true
        });
    } else {
        browser.storage.local.set({
            extractFromAlltabs: false
        });
    }
  },

  restoreEmailExtractorOptions: function() {

    function setCurrentChoice(result) {
      if (result.extractFromAlltabs) {
        document.querySelector("#extractionChoiceAll").checked = true;
      }
    }

    function onError(error) {
      console.log(`Error: ${error}`);
    }

    var getting = browser.storage.local.get("extractFromAlltabs");
    getting.then(setCurrentChoice, onError);
  }
}

document.addEventListener("DOMContentLoaded", emailExtractorOptions.restoreEmailExtractorOptions);
document.querySelector("#extractionChoiceAll").addEventListener("change", emailExtractorOptions.saveEmailExtractorOptions);