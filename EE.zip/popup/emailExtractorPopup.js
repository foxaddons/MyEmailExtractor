/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 2/GPL 3.0/LGPL 3.0
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this file,
 * You can obtain one at http://mozilla.org/MPL/2.0/.
 * 
 * 
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Email Extractor pro.
 *
 * The Initial Developer of the Original Code is
 * Rejah Rehim A A.
 * Portions created by the Initial Developer are Copyright (C) 2017
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 * 
 * ***** END LICENSE BLOCK ***** */

"use strict";

var emailExtractor = {

  extractedEmails: [],
  extractFromAlltabs : false,
  listenForClicks: function() {
    
       emailExtractor.probeTabsToParseEmails();


  document.querySelector("#cpyall").addEventListener("click", (e) => {
      emailExtractor.copyEmails();
    });


/*
document.querySelector("#extractEmails").addEventListener("click", (e) => {
      emailExtractor.probeTabsToParseEmails();
    });
    document.querySelector("#save").addEventListener("click", (e) => {
      emailExtractor.saveAsEmailExtractorBox();
    });
    document.querySelector("#cpyall").addEventListener("click", (e) => {
      emailExtractor.copyEmails();
    });

*/

  },

  cleanExtractedEmails: function(origEmailArr) {  
        var newEmailArr = [], origEmailArrLen = origEmailArr.length, emailFound, i, j;  
              
        for ( i = 0; i < origEmailArrLen; i++ ) {  
            emailFound = undefined; 
            
            for ( j = 0; j < newEmailArr.length; j++ ) {  
                if (origEmailArr[i] === newEmailArr[j] ) {   
                    emailFound = true;  
                    break;  
                }  
            } 
            
            if (origEmailArr[i] !== null) {
                if ( !emailFound) newEmailArr.push( origEmailArr[i] );    
            }  
        }  
       return newEmailArr;  
  },

  printResult: function (extractedEmailsArray){
          var extractedEmailBoxNode=document.createElement("div");

          extractedEmailBoxNode.style.display = 'block';
          extractedEmailBoxNode.style.overflow = 'hidden';
          
          for (var i = 0; i < extractedEmailsArray.length; i++) {
              var extractedEmailParaNode=document.createElement("a");


var temp = extractedEmailsArray[i];

if (temp.endsWith("."))
{	temp = temp.substring(0, temp.length - 1); }

              var extractedEmailNode = document.createTextNode(temp);


extractedEmailParaNode.title = temp;

extractedEmailParaNode.href = "mailto:" + temp;


              extractedEmailParaNode.appendChild(extractedEmailNode);
              extractedEmailParaNode.style.display = 'block';
              extractedEmailParaNode.style.width = '1020px';
              extractedEmailParaNode.style.clear = 'right';
              extractedEmailParaNode.style.padding = '8px';

              extractedEmailBoxNode.appendChild(extractedEmailParaNode);
          }

          var resultDiv = document.querySelector("#emails-content");
          while (resultDiv.firstChild) {
              resultDiv.removeChild(resultDiv.firstChild);
          }
          resultDiv.appendChild(extractedEmailBoxNode);
          resultDiv.classList.remove("hidden");
          //document.querySelector("#save").classList.remove("hidden");

document.querySelector("#cpyall").classList.remove("hidden");

  },


  copyEmails: function () {

      var resultDiv = document.querySelector("#emails-content");
      var outString = resultDiv.innerHTML;

      var emailsArr = outString.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi);

      var strlocalcpy = "";

      var UArrayLocal = emailExtractor.cleanExtractedEmails(emailsArr);     

      for (var i = 0; i < UArrayLocal.length; i++) 
	 {
 		if (i == (UArrayLocal.length - 1))
		   strlocalcpy += UArrayLocal[i];
		else
      	   strlocalcpy += UArrayLocal[i] + '\r\n';
		 

		 //strlocalcpy += UArrayLocal[i] + String.fromCharCode(13);  // 10 for \n 13 for /r   

        //   strlocalcpy += UArrayLocal[i] + "<br />";      
       }

      navigator.clipboard.writeText(strlocalcpy);

},

  saveAsEmailExtractorBox: function () {

      var resultDiv = document.querySelector("#emails-content");
      var outString = resultDiv.innerHTML.replace(/<(div)[^>]+>/ig,'').replace(/<\/div>/ig,'\r\n')   

      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(outString));
      element.setAttribute('download', 'emails.txt');

      element.style.display = 'none';
      document.body.appendChild(element);

      element.click();

      document.body.removeChild(element);

  },
  onError: function (error) {
        // console.log(`Error: ${error}`);
        return true;
  },
  setEmailExtractionChoice: function() {

    browser.storage.local.get("extractFromAlltabs")
    .then(getChoice, emailExtractor.onError);

    function getChoice(result) {
      if (result.extractFromAlltabs) {
        emailExtractor.extractFromAlltabs =  true;
      }
    }

  },
  parseMessagefromTab: function(connection) {
    connection.onMessage.addListener(function(message) {
      if (message.emails) {
          emailExtractor.extractedEmails  = emailExtractor.extractedEmails.concat(message.emails);
          var cleanedEmails = emailExtractor.cleanExtractedEmails(emailExtractor.extractedEmails);
          emailExtractor.printResult(cleanedEmails);
      }
    });
  },

  probeTabsToParseEmails: async function () {

    emailExtractor.setEmailExtractionChoice()

    /* Listern for the response from the Tabs*/
    browser.runtime.onConnect.addListener(emailExtractor.parseMessagefromTab);

    let tabs = await browser.tabs.query({});

    if (emailExtractor.extractFromAlltabs){
      for (let tab of tabs) {

          function getEmailsFromTab(tabs) {
                browser.tabs.sendMessage(tab.id, {
                  command: "getemails"
                }).catch(emailExtractor.onError);
              
          }

          await browser.tabs.query({currentWindow: true})
          .then(getEmailsFromTab)
          .catch(emailExtractor.reportExecuteScriptError);
      } 
     
    } else {
          function getEmailsFromTab(tabs) {
                browser.tabs.sendMessage(tabs[0].id, {
                  command: "getemails"
                }).catch(emailExtractor.reportExecuteScriptError);
              
          }
          await browser.tabs.query({active: true, currentWindow: true})
          .then(getEmailsFromTab)
          .catch(emailExtractor.reportExecuteScriptError); 

    }
    
  },

  reportExecuteScriptError: function(error) {
    document.querySelector("#popup-content").classList.add("hidden");
    document.querySelector("#error-content").classList.remove("hidden");
    // console.error(`Failed to execute content script: ${error.message}`);
  }
}

emailExtractor.listenForClicks()